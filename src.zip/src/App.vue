<template>
  <div class="toutiao">
    <router-view></router-view>
  </div>
</template>

<script>
export default {}
</script>

<style scoped lang="less">
  .box{
    width: 2rem;
    height: 2rem;
    background-color: lightblue;
  }
</style>
